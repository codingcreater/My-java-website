import java.util.Date;
class A{
    public static void main(String a[])
    {
        Date obj = new  Date();
        System.out.println(obj); 
    }
}