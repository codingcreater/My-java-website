/*
-   programmer:MayankDevil
-   9. Write a Java program to check whether Java is installed on your computer or not
*/ 
class Test
{
    public static void main(String args[])
    {
        System.out.println("{ Java is Installed }");    // if not installed fail to execute
    }
}
// the end