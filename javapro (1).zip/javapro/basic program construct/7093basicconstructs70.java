//convert characters of a string into lowercase

class Change
{
public static void main(String[] args){
String strng= "WE ARE STUDENTS OF PGGC11";
System.out.println("String before convert into lowercase ="+strng);
strng=strng.toLowerCase();
System.out.print("String after convert into lowercase ="+strng);

}
}