/*
-   programmer:MayankDevil
-   1. Write a Java program to print 'Hello World!' on screen
*/ 
class Test
{
    public static void main(String args[])
    {
        System.out.println("Hello World");
    }
}
// the end