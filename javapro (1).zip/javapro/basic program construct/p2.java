class p2 {
    public static void main(String args[]) {
        int a = 12390;
        int b = 440;
        int c = a + b;
        System.out.println("The Sum og given number is :" + c);
    }
}
