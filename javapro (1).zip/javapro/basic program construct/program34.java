/*
-   programmer:MayankDevil
-   34. Java Program to find volume of sphere
*/ 
class Test
{
    public static void main(String args[])
    {        
        double radius = 2.0;
        
        System.out.printf("The volume of the sphere is %.2f cubic units.",((4.0 / 3.0) * Math.PI * Math.pow(radius, 3)));
    }
}
// the end