// 58. Write java program to display first 5 natural numbers    By Aryan chugh(7058/21)
 
class natural{

public static void main(String args[]){
int a=1;
System.out.println("The first 5 natural numbers are:");
for(a=1;a<=5;a++){
System.out.println(a);
}
} 
}